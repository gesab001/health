import json

f = open("bk-mh-02.json", "r")
jsonData = json.loads(f.read())

for x in range(0, len(jsonData)):
  print(jsonData[x])